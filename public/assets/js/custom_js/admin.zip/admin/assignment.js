$(document).ready(function() {
    if (pageType == 'assignment_level_list') {
        loadAssignmentLevelTable();
    } else if (pageType == 'assignment_list') {
        loadAssignmentListTable();
    }

    function loadAssignmentLevelTable() {
        $("#ass_sub_table").DataTable({
            "pagingType": "full_numbers",
            "lengthMenu": [
                [10, 25, 50, 100],
                [10, 25, 50, 100],
            ],
            "responsive": true,
            "language": {
                "search": "_INPUT_",
                "searchPlaceholder": "search_records",
            },
            "iDisplayLength": 10,
            "order": [
                [0, "desc"],
            ],
            "columnDefs": [{
                "targets": [0, 1],
                "className": "text-center",
                "orderable": false,
            }],
            "scrollX": true,
            "autoWidth": false,
            "destroy": true,
            "processing": true,
            "serverSide": true,
            "serverMethod": 'POST',
            "ajax": {
                "url": baseUrl + 'admin/fetch-assignment-level-list',
            },
            drawCallback: function(settings, json) {
                $(".assignmentViewBtn").on('click', function() {
                    var level_id = $(this).data('level-id');
                    var url = baseUrl + 'admin/assignment-list/' + level_id;
                    window.open(url);
                });
            }
        });
    }

    function loadAssignmentListTable() {
        var level_id = $("#level_id").val();
        $("#assignment_table").DataTable({
            "pagingType": "full_numbers",
            "lengthMenu": [
                [10, 25, 50, 100],
                [10, 25, 50, 100],
            ],
            "responsive": true,
            "language": {
                "search": "_INPUT_",
                "searchPlaceholder": "search_records",
            },
            "iDisplayLength": 10,
            "order": [
                [0, "desc"],
            ],
            "columnDefs": [{
                "targets": [7, 9],
                "className": "text-center",
                "orderable": false,
            }],
            "scrollX": true,
            "autoWidth": false,
            "destroy": true,
            "processing": true,
            "serverSide": true,
            "serverMethod": 'POST',
            "ajax": {
                "url": baseUrl + 'admin/fetch-assignment-list',
                data: {
                    level_id: level_id,
                }
            },
            drawCallback: function(settings, json) {

            }
        });
    }

    $(".downloadRecheckCSVBtn").on('click', function() {
        var onlyChecked = $("#onlyCheck").is(':checked');
        onlyChecked = onlyChecked ? 1 : 0;
        var dataTableSearch = $(".dataTables_filter").find('input').val();
        var level_id = $("#level_id").val();
        var url = baseUrl + 'admin/upload-recheck/export?onlyChecked=' + onlyChecked + '&level_id=' + level_id + '&dataTableSearch=' + dataTableSearch;
        window.open(url, '_blank');
    })

})